# electromagnetism.md

## 1. MAGNETIC FLUX
Phi = B*A*cos(theta)

## 2. FLUX LINKAGE
lambda = N*Phi

## 3. INDUCTIVE EMF
emf = -L*(dI/dt)
Use:
L = abs(emf/(dI/dt))

## 4. SOLENOID INDUCTANCE
L = mu0*N**2*A/l

## 5. CONSTANT
- Permeability of free space constant syntax: `mu0 = sp.Float('4') * sp.pi * sp.Float('1e-7')`

## 6. ENERGY DENSITY
u = B**2/(2*mu0)